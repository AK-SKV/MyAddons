__author__ = 'deimos'

from . import polymorphism