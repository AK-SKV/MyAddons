# builder local module import

allows to import module info, models, views and menus from local modules to view in the module builder. this should be used as an
exploration tool. As an exercise try to import the builder with this tool and see the relations, models and module info.