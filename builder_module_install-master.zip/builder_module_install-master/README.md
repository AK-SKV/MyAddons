allow to install, upgrade and uninstall a builder module from the module view.
